package assignment;

public class Assignment {
    
    public static void main(String[] args) {
       new Dashboard().setVisible(true);
         
        
    }
    
}
