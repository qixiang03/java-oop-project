package assignment;



public class TreesU extends javax.swing.JFrame {

    
    public TreesU() {
        initComponents();
       
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea6 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        TitleLabel1 = new javax.swing.JLabel();
        DirectoryLabel1 = new javax.swing.JLabel();
        DirectoryLabel2 = new javax.swing.JLabel();
        DirectoryLabel3 = new javax.swing.JLabel();
        TitleLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        ImgLabel1 = new javax.swing.JLabel();
        ImgLabel2 = new javax.swing.JLabel();
        ImgLabel3 = new javax.swing.JLabel();
        ImgLabel4 = new javax.swing.JLabel();
        ImgLabel5 = new javax.swing.JLabel();
        ImgLabel6 = new javax.swing.JLabel();
        DirectoryLabel4 = new javax.swing.JLabel();
        DirectoryLabel5 = new javax.swing.JLabel();
        DirectoryLabel8 = new javax.swing.JLabel();
        DirectoryLabel9 = new javax.swing.JLabel();
        DirectoryLabel10 = new javax.swing.JLabel();
        DirectoryLabel11 = new javax.swing.JLabel();
        DirectoryLabel12 = new javax.swing.JLabel();
        DirectoryLabel13 = new javax.swing.JLabel();
        DirectoryLabel14 = new javax.swing.JLabel();
        DirectoryLabel15 = new javax.swing.JLabel();
        DirectoryLabel16 = new javax.swing.JLabel();
        DirectoryLabel17 = new javax.swing.JLabel();
        DirectoryLabel18 = new javax.swing.JLabel();
        DirectoryLabel19 = new javax.swing.JLabel();
        DirectoryLabel20 = new javax.swing.JLabel();
        DirectoryLabel21 = new javax.swing.JLabel();
        DirectoryLabel22 = new javax.swing.JLabel();
        DirectoryLabel23 = new javax.swing.JLabel();
        DirectoryLabel24 = new javax.swing.JLabel();
        DirectoryLabel25 = new javax.swing.JLabel();
        DirectoryLabel26 = new javax.swing.JLabel();
        DirectoryLabel28 = new javax.swing.JLabel();
        DirectoryLabel29 = new javax.swing.JLabel();
        DirectoryLabel30 = new javax.swing.JLabel();
        DirectoryLabel31 = new javax.swing.JLabel();
        DirectoryLabel32 = new javax.swing.JLabel();
        DirectoryLabel27 = new javax.swing.JLabel();
        DirectoryLabel7 = new javax.swing.JLabel();
        DirectoryLabel6 = new javax.swing.JLabel();

        jTextArea2.setEditable(false);
        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jTextArea2.setText("Trees play a key role\n in capturing \nrainwater and \nreducing the risk of\n natural disasters\n like floods and \nlandslides.");
        jScrollPane2.setViewportView(jTextArea2);

        jTextArea4.setEditable(false);
        jTextArea4.setColumns(20);
        jTextArea4.setRows(5);
        jTextArea4.setText("A single tree can be\nhome to hundreds\nof species and \nanimlas ");
        jScrollPane4.setViewportView(jTextArea4);

        jTextArea6.setEditable(false);
        jTextArea6.setColumns(20);
        jTextArea6.setRows(5);
        jTextArea6.setText("Trees help reduce \nstress and anxiety, \nand allow us to \nreconnect with \nnature.");
        jScrollPane6.setViewportView(jTextArea6);

        jTextArea3.setEditable(false);
        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jTextArea3.setText("Trees help cool the \nplanet by sucking in\nand storing harmful \ngreenhouse gases \nlike carbon dioxide\nand release oxygen");
        jScrollPane3.setViewportView(jTextArea3);

        jTextArea5.setEditable(false);
        jTextArea5.setColumns(20);
        jTextArea5.setRows(5);
        jTextArea5.setText("From arborists to \nloggers and \nresearchers, the job \nopportunities \nprovided by the \nforestry industry are\nendless.");
        jScrollPane5.setViewportView(jTextArea5);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(900, 480));

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));

        TitleLabel1.setFont(new java.awt.Font("Segoe UI Symbol", 1, 24)); // NOI18N
        TitleLabel1.setForeground(new java.awt.Color(255, 255, 255));
        TitleLabel1.setText("WHY TREE ARE IMPORTANT TO THE ENVIRONMENT?");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TitleLabel1)
                .addGap(159, 159, 159))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(TitleLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        DirectoryLabel1.setText("Trees help clean the air we breathe, filter the water we drink, and provide habitat to over 80% of the world's terrestrial biodiversity.");

        DirectoryLabel2.setText("Forests provide jobs to over 1.6 billion people, absorb harmful carbon from the atmosphere, and are key ingredients in 25% of all");

        DirectoryLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        DirectoryLabel3.setText("medicines. Have you ever taken an Aspirin? It comes from the bark of a tree!");

        TitleLabel2.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        TitleLabel2.setText("6 PILLAR THAT EXPLAIN TREES ARE VITAL TO THE ENVIRONMENT ");
        TitleLabel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        ImgLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/air.jpg"))); // NOI18N
        ImgLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ImgLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/water.jpg"))); // NOI18N
        ImgLabel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ImgLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/bioadversity.jpg"))); // NOI18N
        ImgLabel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ImgLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/health.jpg"))); // NOI18N
        ImgLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ImgLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/climate.jpg"))); // NOI18N
        ImgLabel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ImgLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/social impact.jpg"))); // NOI18N
        ImgLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        DirectoryLabel4.setText("Trees provide fresh");

        DirectoryLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DirectoryLabel5.setText("air and regulate");

        DirectoryLabel8.setText("Trees play a key role");

        DirectoryLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        DirectoryLabel9.setText("in capturing rainwater");

        DirectoryLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        DirectoryLabel10.setText("and reducing the risk");

        DirectoryLabel11.setText("of natural disaster ");

        DirectoryLabel12.setText("like floods and ");

        DirectoryLabel13.setText("landslides.");

        DirectoryLabel14.setText("A single tree can be");

        DirectoryLabel15.setText("a home of hundreds");

        DirectoryLabel16.setText("of species.");

        DirectoryLabel17.setText("Trees help us reduce");

        DirectoryLabel18.setText("stress and anxiety,");

        DirectoryLabel19.setText("and allow us to ");

        DirectoryLabel20.setText("reconnect with the ");

        DirectoryLabel21.setText("nature.");

        DirectoryLabel22.setText("Trees help cool the ");

        DirectoryLabel23.setText("planet by sucking in ");

        DirectoryLabel24.setText("and storing harmful");

        DirectoryLabel25.setText("greenhouses gas like");

        DirectoryLabel26.setText("carbon dioxide and ");

        DirectoryLabel28.setText("From arborists to ");

        DirectoryLabel29.setText("loggers and researches");

        DirectoryLabel30.setText("the job opportunities");

        DirectoryLabel31.setText("provided by the forest");

        DirectoryLabel32.setText("are endless.");

        DirectoryLabel27.setText("release oxygen ");

        DirectoryLabel7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DirectoryLabel7.setText("dioxide ratio.");

        DirectoryLabel6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        DirectoryLabel6.setText("oxygen to carbon");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(ImgLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(DirectoryLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DirectoryLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(DirectoryLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DirectoryLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(29, 29, 29)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(DirectoryLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ImgLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DirectoryLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ImgLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DirectoryLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DirectoryLabel14)
                    .addComponent(DirectoryLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(DirectoryLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ImgLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DirectoryLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(37, 37, 37)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(DirectoryLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ImgLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(DirectoryLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DirectoryLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DirectoryLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DirectoryLabel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(DirectoryLabel27))
                .addGap(35, 35, 35)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ImgLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DirectoryLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DirectoryLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(26, 26, 26))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ImgLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ImgLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ImgLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ImgLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ImgLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ImgLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DirectoryLabel4)
                    .addComponent(DirectoryLabel8)
                    .addComponent(DirectoryLabel14)
                    .addComponent(DirectoryLabel17)
                    .addComponent(DirectoryLabel22)
                    .addComponent(DirectoryLabel28))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DirectoryLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(DirectoryLabel5)
                        .addComponent(DirectoryLabel9)
                        .addComponent(DirectoryLabel18)
                        .addComponent(DirectoryLabel23)
                        .addComponent(DirectoryLabel29)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DirectoryLabel10)
                            .addComponent(DirectoryLabel16)
                            .addComponent(DirectoryLabel19)
                            .addComponent(DirectoryLabel24)
                            .addComponent(DirectoryLabel30))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DirectoryLabel11)
                            .addComponent(DirectoryLabel20)
                            .addComponent(DirectoryLabel25)
                            .addComponent(DirectoryLabel31)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(DirectoryLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DirectoryLabel7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DirectoryLabel12)
                    .addComponent(DirectoryLabel21)
                    .addComponent(DirectoryLabel26)
                    .addComponent(DirectoryLabel32))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DirectoryLabel13)
                    .addComponent(DirectoryLabel27))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(DirectoryLabel2))
                                    .addComponent(DirectoryLabel1))
                                .addGap(101, 101, 101))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(DirectoryLabel3)
                                .addGap(260, 260, 260))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(TitleLabel2)
                                .addGap(174, 174, 174))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DirectoryLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DirectoryLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DirectoryLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(TitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TreesU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TreesU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TreesU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TreesU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TreesU().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DirectoryLabel1;
    private javax.swing.JLabel DirectoryLabel10;
    private javax.swing.JLabel DirectoryLabel11;
    private javax.swing.JLabel DirectoryLabel12;
    private javax.swing.JLabel DirectoryLabel13;
    private javax.swing.JLabel DirectoryLabel14;
    private javax.swing.JLabel DirectoryLabel15;
    private javax.swing.JLabel DirectoryLabel16;
    private javax.swing.JLabel DirectoryLabel17;
    private javax.swing.JLabel DirectoryLabel18;
    private javax.swing.JLabel DirectoryLabel19;
    private javax.swing.JLabel DirectoryLabel2;
    private javax.swing.JLabel DirectoryLabel20;
    private javax.swing.JLabel DirectoryLabel21;
    private javax.swing.JLabel DirectoryLabel22;
    private javax.swing.JLabel DirectoryLabel23;
    private javax.swing.JLabel DirectoryLabel24;
    private javax.swing.JLabel DirectoryLabel25;
    private javax.swing.JLabel DirectoryLabel26;
    private javax.swing.JLabel DirectoryLabel27;
    private javax.swing.JLabel DirectoryLabel28;
    private javax.swing.JLabel DirectoryLabel29;
    private javax.swing.JLabel DirectoryLabel3;
    private javax.swing.JLabel DirectoryLabel30;
    private javax.swing.JLabel DirectoryLabel31;
    private javax.swing.JLabel DirectoryLabel32;
    private javax.swing.JLabel DirectoryLabel4;
    private javax.swing.JLabel DirectoryLabel5;
    private javax.swing.JLabel DirectoryLabel6;
    private javax.swing.JLabel DirectoryLabel7;
    private javax.swing.JLabel DirectoryLabel8;
    private javax.swing.JLabel DirectoryLabel9;
    private javax.swing.JLabel ImgLabel1;
    private javax.swing.JLabel ImgLabel2;
    private javax.swing.JLabel ImgLabel3;
    private javax.swing.JLabel ImgLabel4;
    private javax.swing.JLabel ImgLabel5;
    private javax.swing.JLabel ImgLabel6;
    private javax.swing.JLabel TitleLabel1;
    private javax.swing.JLabel TitleLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextArea jTextArea6;
    // End of variables declaration//GEN-END:variables
}
